﻿namespace ContactManager.Application.Dtos;

public class UserRoleDto
{
    public long UserRoleId { get; set; }
    public string UserRoleName { get; set; }
    public string Description { get; set; }
}
