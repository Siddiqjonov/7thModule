﻿namespace ContactManager.Application.Dtos;

public class UserRoleCreateDto
{
    public string UserRoleName { get; set; }
    public string Description { get; set; }
}
