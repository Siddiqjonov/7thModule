﻿namespace ContactMangerTest.ContactServiceTests;

public class AuthServiceTests
{
}
